package com.POJO;

public class Data {

	
	
	String FIRSTNAME;
	String LASTNAME;
	String CONTACTNO;
	public String getFIRSTNAME() {
		return FIRSTNAME;
	}
	public void setFIRSTNAME(String fIRSTNAME) {
		FIRSTNAME = fIRSTNAME;
	}
	public String getLASTNAME() {
		return LASTNAME;
	}
	public void setLASTNAME(String lASTNAME) {
		LASTNAME = lASTNAME;
	}
	public String getCONTACTNO() {
		return CONTACTNO;
	}
	public void setCONTACTNO(String cONTACTNO) {
		CONTACTNO = cONTACTNO;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
